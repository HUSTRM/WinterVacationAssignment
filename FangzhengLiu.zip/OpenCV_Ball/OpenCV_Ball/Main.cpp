#include "Ball.h"

int main(int argc, char **argv) {
	int BoardLength = NUM_CAM_HEIGHT;
	int ColorBluePure = 0x0000FF;
	unsigned int SerialInterval = 0;
	unsigned int CounterId = 0;
	unsigned int CounterSent = 0;
	HANDLE Serial = INVALID_HANDLE_VALUE;
	Mat FrameCurrent;
	Scalar ColorBlue = Scalar(0xC5, 0x73, 0x16);
	Scalar ColorCyan = Scalar(0xC7, 0xC0, 0x48);
	Scalar ColorGreen = Scalar(0x36, 0x92, 0x35);
	Scalar ColorRed = Scalar(0x00, 0x00, 0xFF);
	SYSTEMTIME TimePast;
	vector<Point> PointCircles(9);

	cout << "[Info] Initialization." << endl;
	for (int i = 0; i < 3; ++i) {
		for (int j = 0; j < 3; ++j) {
			PointCircles[i * 3 + j].x = static_cast<int>((125 + j * 200) / 10 * NUM_CM2PX);
			PointCircles[i * 3 + j].y = static_cast<int>((125 + i * 200) / 10 * NUM_CM2PX);
		}
	}
	if (argc > 1 && !strcmp(argv[1], "/serial")) {
		InitSerialData Data = { 0,0,0,NULL,"" };
		InitializeSerial(Data);
		if (Data.Serial == INVALID_HANDLE_VALUE) PrintErrorExit(Data.Error, Data.Content);
		Serial = Data.Serial;
		cout << "       Using COM" << Data.COM << ". Baudrate: " << Data.Baudrate << "bps.";
		if (argc > 2 && atoi(argv[2]) > 0) SerialInterval = atoi(argv[2]);
		else SerialInterval = NUM_COM_INTERVAL;
		cout << " Interval: " << SerialInterval << "ms." << endl;
		GetLocalTime(&TimePast);
	}
	else cout << "       Serial port communication is not enabled." << endl;
	cout << "[Info] Connection to camera is being established." << endl;
	VideoCapture Camera(0);
	if (!Camera.isOpened()) {
		cerr << "[Error] No camera is currently available." << endl;
		system("pause > nul");
		return ERR_CAM_NOAVALIABLE;
	}
	if (!Camera.get(CAP_PROP_FPS)) {
		cerr << "[Error] Connection to camera is not established." << endl;
		system("pause > nul");
		return ERR_CAM_NOCONNECTION;
	}
	Camera.set(CAP_PROP_FRAME_WIDTH, NUM_CAM_WIDTH);
	Camera.set(CAP_PROP_FRAME_HEIGHT, NUM_CAM_HEIGHT);
	printf("[Info] Camera is currently running. %.0f * %.0f @ %.0f fps.\n",
		Camera.get(CAP_PROP_FRAME_WIDTH), Camera.get(CAP_PROP_FRAME_HEIGHT), Camera.get(CAP_PROP_FPS));
	printf("       Brightness: %.0f, Exposure: %.0f, Focus: %.0f\n",
		Camera.get(CAP_PROP_BRIGHTNESS), Camera.get(CAP_PROP_EXPOSURE), Camera.get(CAP_PROP_FOCUS));
	cout << "[Info] Press 'q' to terminate or 'b' to pause." << endl;
	namedWindow(STR_TITLE_BALL, WINDOW_AUTOSIZE);
	namedWindow(STR_TITLE_BOARD, WINDOW_AUTOSIZE);
	namedWindow(STR_TITLE_FULL, WINDOW_AUTOSIZE);
	namedWindow(STR_TITLE_SEG, WINDOW_AUTOSIZE);
	Camera >> FrameCurrent;
	while (true) {
		char SignalWait = 0;
		char BoardText[32] = { 0 };
		char FCText[2][32] = { "Position:",0 };
		unsigned short SerialData[3] = { 0,0,0 };
		Mat ImageBoard;
		Mat ImageSegmentation;
		Mat ImageTemp;
		Mat TransformPerspective;
		Point PointBall = Point(0, 0);
		Point PointBallMM = Point(0, 0);
		vector<Point2f> ContourTetragon;
		vector<Point2f> TransformTo = { Point2f(0, 0), Point2f(BoardLength, 0),
			Point2f(BoardLength, BoardLength), Point2f(0, BoardLength) };

		printf("[Info] ID: %06u", CounterId++);
		Camera >> FrameCurrent;
		cvtColor(FrameCurrent, ImageSegmentation, COLOR_BGR2HSV);
		inRange(ImageSegmentation, Scalar(15, 0, 100), Scalar(35, 255, 255), ImageSegmentation);
		erode(ImageSegmentation, ImageSegmentation, getStructuringElement(MORPH_RECT, Size(5, 5)), Point(-1, -1), 2);
		dilate(ImageSegmentation, ImageSegmentation, getStructuringElement(MORPH_RECT, Size(5, 5)), Point(-1, -1), 1);
		imshow(STR_TITLE_SEG, ImageSegmentation);
		if ((SignalWait = waitKey(NUM_IMSHOW_DELAY)) == 'q') break;
		else if (SignalWait == 'b') system("pause > nul");
		ContourTetragon = FindBoard(ImageSegmentation, NUM_APPROX_EPS, FrameCurrent.rows*FrameCurrent.cols / 3);
		if (ContourTetragon.empty()) {
			cout << "   Discarded due to board-detection failure." << endl;
			sprintf(FCText[1], "NOT FOUND");
			putText(FrameCurrent, FCText[0], Point(15, 47), FONT_HERSHEY_SIMPLEX, NUM_TEXT_SCALE, ColorRed, NUM_THICKNESS);
			putText(FrameCurrent, FCText[1], Point(20, 95), FONT_HERSHEY_SIMPLEX, NUM_TEXT_SCALE, ColorRed, NUM_THICKNESS);
			GenerateNoSignal(ImageBoard, Size(BoardLength, BoardLength), ColorBluePure);
			GenerateNoSignal(ImageTemp, Size(BoardLength, BoardLength), ColorBluePure);
			imshow(STR_TITLE_FULL, FrameCurrent);
			imshow(STR_TITLE_BOARD, ImageBoard);
			imshow(STR_TITLE_SEG, ImageSegmentation);
			imshow(STR_TITLE_BALL, ImageTemp);
			if ((SignalWait = waitKey(NUM_IMSHOW_DELAY)) == 'q') break;
			else if (SignalWait == 'b') system("pause > nul");
			if (argc > 1 && !strcmp(argv[1], "/serial")) {
				SendDataConf Configuration;
				Configuration = { 0,SerialInterval,	NUM_COM_DATASIZE,
					0,Serial,PointBallMM,"",TimePast };
				SendData(Configuration);
				if (Configuration.Error != 0) PrintErrorExit(Configuration.Error, Configuration.Content);
				if (Configuration.Transferred > 0) {
					cout << "                    Serial port: Package ";
					printf("%06u", CounterSent++);
					cout << " :: " << Configuration.Transferred << " of " << Configuration.Size
						<< " bytes of data has been sent." << endl;
					TimePast = Configuration.Past;
				}
				else cout << endl;
			}
			continue;
		}
		ContourTetragon = SortVertex(ContourTetragon);
		TransformPerspective = getPerspectiveTransform(ContourTetragon, TransformTo);
		warpPerspective(FrameCurrent, ImageBoard, TransformPerspective, Size(BoardLength, BoardLength));
		DrawTetragon(FrameCurrent, ContourTetragon, ColorCyan, NUM_THICKNESS);
		sprintf(FCText[1], "(%.0f, %.0f)(%.0f, %.0f)(%.0f, %.0f)(%.0f, %.0f)",
			ContourTetragon[0].x, ContourTetragon[0].y, ContourTetragon[1].x, ContourTetragon[1].y,
			ContourTetragon[2].x, ContourTetragon[2].y, ContourTetragon[3].x, ContourTetragon[3].y);
		putText(FrameCurrent, FCText[0], Point(15, 47), FONT_HERSHEY_SIMPLEX, NUM_TEXT_SCALE, ColorRed, NUM_THICKNESS);
		putText(FrameCurrent, FCText[1], Point(20, 95), FONT_HERSHEY_SIMPLEX, NUM_TEXT_SCALE, ColorRed, NUM_THICKNESS);
		for (int i = 0; i < 9; ++i)
			circle(ImageBoard, PointCircles[i], static_cast<int>(3 / 2 * NUM_CM2PX), ColorRed, NUM_THICKNESS);
		warpPerspective(ImageSegmentation, ImageTemp, TransformPerspective, Size(BoardLength, BoardLength));
		imshow(STR_TITLE_BALL, ImageTemp);
		if ((SignalWait = waitKey(NUM_IMSHOW_DELAY)) == 'q') break;
		else if (SignalWait == 'b') system("pause > nul");
		PointBall = FindBall(ImageTemp, NUM_MARGIN_UD, NUM_MARGIN_LR, NUM_BALL_RADIUS);
		if (PointBall.x == 0 && PointBall.y == 0) sprintf(BoardText, "Position: NOT FOUND");
		else {
			PointBallMM.x = static_cast<unsigned short>(PointBall.x / NUM_CM2PX * 10);
			PointBallMM.y = static_cast<unsigned short>(PointBall.y / NUM_CM2PX * 10);
			circle(ImageBoard, PointBall, NUM_DRAWC_RADIUS, ColorGreen, NUM_THICKNESS);
			sprintf(BoardText, "Position: (%dmm, %dmm)", PointBallMM.x, PointBallMM.y);
		}
		putText(ImageBoard, BoardText, Point(15, 47), FONT_HERSHEY_SIMPLEX, 1.0, ColorBlue, NUM_THICKNESS);
		imshow(STR_TITLE_BOARD, ImageBoard);
		if ((SignalWait = waitKey(NUM_IMSHOW_DELAY)) == 'q') break;
		else if (SignalWait == 'b') system("pause > nul");
		imshow(STR_TITLE_FULL, FrameCurrent);
		if ((SignalWait = waitKey(NUM_IMSHOW_DELAY)) == 'q') break;
		else if (SignalWait == 'b') system("pause > nul");
		if (argc > 1 && !strcmp(argv[1], "/serial")) {
			SendDataConf Configuration;
			Configuration = { 0,SerialInterval,	NUM_COM_DATASIZE,
				0,Serial,PointBallMM,"",TimePast };
			SendData(Configuration);
			if (Configuration.Error != 0) PrintErrorExit(Configuration.Error, Configuration.Content);
			if (Configuration.Transferred > 0) {
				cout << "   Serial port: Package ";
				printf("%06u", CounterSent++);
				cout << " :: " << Configuration.Transferred << " of " << Configuration.Size
					<< " bytes of data has been sent." << endl;
				TimePast = Configuration.Past;
			}
			else cout << endl;
		}
		else cout << "   Operation is successfully completed." << endl;
	}
	destroyAllWindows();
	if (argc > 1 && !strcmp(argv[1], "/serial"))
		if (!CloseHandle(Serial)) cout << "[Warning] Serial port is not closed correctly." << endl;
	cout << "\n[Info] Display is terminiated. Press any key to quit." << endl;
	system("pause > nul");

	return 0;
}