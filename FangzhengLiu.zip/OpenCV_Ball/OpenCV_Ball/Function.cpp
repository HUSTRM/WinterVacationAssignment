#include "Ball.h"

void DrawTetragon(Mat &Image, vector<Point2f> Vertices, Scalar Color, int Thickness) {
	if (Vertices.size() != 4) return;
	line(Image, Vertices[0], Vertices[1], Color, Thickness);
	line(Image, Vertices[1], Vertices[2], Color, Thickness);
	line(Image, Vertices[2], Vertices[3], Color, Thickness);
	line(Image, Vertices[3], Vertices[0], Color, Thickness);
}

void GenerateNoSignal(Mat &Image, Size ImageSize, int ColorHex) {
	if (ColorHex == 0) return;

	Image = Mat::zeros(ImageSize, CV_8UC3);
	for (int i = 0, j = Image.rows; i < j; ++i) {
		for (int m = 0, n = Image.cols; m < n; ++m) {
			Vec3b &Pixel = Image.at<Vec3b>(i, m);
			Pixel[Red] = ColorHex & 0xFF0000;
			Pixel[Green] = ColorHex & 0x00FF00;
			Pixel[Blue] = ColorHex & 0x0000FF;
		}
	}
	for (int i = 15; i < 63; ++i) {
		for (int j = 15; j < 180; ++j) {
			Vec3b &Pixel = Image.at<Vec3b>(i, j);
			Pixel[Red] = 0;
			Pixel[Green] = 0;
			Pixel[Blue] = 0;
		}
	}
	putText(Image, "No Signal", Point(20, 50), FONT_HERSHEY_SIMPLEX, 1.0, Scalar(255, 255, 255), NUM_THICKNESS);
}

void InitializeSerial(InitSerialData &Data) {
	char Port[8] = { 0 };
	COMMTIMEOUTS Timeout;
	DCB Control;
	HANDLE Serial;

	for (int i = 0; i <= 10; ++i) {
		if (i == 10) {
			Data.Error = ERR_COM_OPEN;
			Data.Serial = INVALID_HANDLE_VALUE;
			Data.Content = "No serial port is avaliable.";
		}
		sprintf(Port, "COM%d:", i);
		Serial = CreateFileA(_T(Port), GENERIC_WRITE, 0, NULL, OPEN_EXISTING, NULL, NULL);
		if (Serial == INVALID_HANDLE_VALUE) continue;
		Data.Serial = Serial;
		Data.COM = i;
		if (!SetupComm(Serial, 1024, 1024)) {
			Data.Error = ERR_COM_BUFSIZE;
			Data.Serial = INVALID_HANDLE_VALUE;
			Data.Content = "An error occurred while setting up buffer size.";
		}
		Timeout.ReadIntervalTimeout = 0;
		Timeout.ReadTotalTimeoutConstant = 10240;
		Timeout.ReadTotalTimeoutMultiplier = 1024;
		Timeout.WriteTotalTimeoutConstant = 10240;
		Timeout.WriteTotalTimeoutMultiplier = 1024;
		if (!SetCommTimeouts(Serial, &Timeout)) {
			Data.Error = ERR_COM_SETTOUT;
			Data.Serial = INVALID_HANDLE_VALUE;
			Data.Content = "An error occurred while setting up timeout parameters.";
		}
		if (!GetCommState(Serial, &Control)) {
			Data.Error = ERR_COM_GETDCB;
			Data.Serial = INVALID_HANDLE_VALUE;
			Data.Content = "An error occurred while getting DCB.";
		}
		Control.BaudRate = NUM_COM_BAUDRATE;
		Control.ByteSize = 8;
		Control.Parity = NOPARITY;
		Control.StopBits = ONESTOPBIT;
		if (!SetCommState(Serial, &Control)) {
			Data.Error = ERR_COM_SETDCB;
			Data.Serial = INVALID_HANDLE_VALUE;
			Data.Content = "An error occurred while setting DCB.";
		}
		Data.Baudrate = Control.BaudRate;
		if (!PurgeComm(Serial, PURGE_RXCLEAR | PURGE_TXCLEAR)) {
			Data.Error = ERR_COM_FLUSH;
			Data.Serial = INVALID_HANDLE_VALUE;
			Data.Content = "An error occurred while flushing buffer.";
		}
		break;
	}
}

void PrintErrorExit(int Error, string Content) {
	cerr << "\n[Error] " << Content << endl;
	system("pause > nul");
	exit(Error);
}

void SendData(SendDataConf &Conf) {
	// Data in  Byte: [5][4]X [3][2]Y [1]CR13 [0]LF10
	// Data in Short:   [2] X   [1] Y    [0]CR+LF
	//          Unit: Millimeter
	//    Convention: (0,0) Not Found
	unsigned int NowMS = 0;
	unsigned int PastMS = 0;
	unsigned short Temp = 0;
	unsigned short Data[3] = { 0 };
	SYSTEMTIME Now;

	Temp = Conf.Data.x < 650 ? Conf.Data.x : 0;
	Data[0] = ((Temp & 0x00FF) << 8) + ((Temp & 0xFF00) >> 8);
	Temp = Conf.Data.y < 650 ? Conf.Data.y : 0;
	Data[1] = ((Temp & 0x00FF) << 8) + ((Temp & 0xFF00) >> 8);
	Data[2] = 0x0A << 8 | 0x0D;
	GetLocalTime(&Now);
	NowMS = Now.wHour * 3600000 + Now.wMinute * 60000 + Now.wSecond * 1000 + Now.wMilliseconds;
	PastMS = Conf.Past.wHour * 3600000 + Conf.Past.wMinute * 60000 + Conf.Past.wSecond * 1000 + Conf.Past.wMilliseconds;
	if (NowMS - PastMS >= Conf.Interval) {
		if (!PurgeComm(Conf.Serial, PURGE_RXABORT | PURGE_RXCLEAR | PURGE_TXABORT | PURGE_TXCLEAR)) {
			Conf.Error = ERR_COM_FLUSH;
			Conf.Content = "An error occurred while flushing buffer.";
		}
		if (!WriteFile(Conf.Serial, Data, Conf.Size, &(Conf.Transferred), NULL)) {
			Conf.Error = ERR_COM_WRITE;
			Conf.Content = "An error occurred while sending data.";
		}
		GetLocalTime(&(Conf.Past));
		if (!PurgeComm(Conf.Serial, PURGE_RXABORT | PURGE_RXCLEAR | PURGE_TXABORT | PURGE_TXCLEAR)) {
			Conf.Error = ERR_COM_FLUSH;
			Conf.Content = "An error occurred while flushing buffer.";
		}
	}
}

Point FindBall(Mat Image, double RangeUD, double RangeLR, double RadiusMinimum) {
	int Extreme[4] = { Image.rows,0,Image.cols,0 };

	for (int i = static_cast<int>(RangeUD), j = static_cast<int>(Image.rows - RangeUD); i < j; ++i) {
		for (int m = static_cast<int>(RangeLR), n = static_cast<int>(Image.cols - RangeLR); m < n; ++m) {
			unsigned char Pixel = Image.at<unsigned char>(i, m);
			if (Pixel == 0) {
				if (i < Extreme[Up]) Extreme[Up] = i;
				if (i > Extreme[Down]) Extreme[Down] = i;
				if (m < Extreme[Left]) Extreme[Left] = m;
				if (m > Extreme[Right]) Extreme[Right] = m;
			}
		}
	}
	if (Extreme[Down] - Extreme[Up] < static_cast<int>(RadiusMinimum)
		&& Extreme[Down] - Extreme[Up] < static_cast<int>(RadiusMinimum))
		return Point(0, 0);
	else return Point((Extreme[Left] + Extreme[Right]) / 2, (Extreme[Up] + Extreme[Down]) / 2);
}

vector<Point2f> FindBoard(Mat Image, int ApproximationError, int AreaMinimum) {
	double Area = 0.0;
	double AreaMaximum = 0.0;
	vector<Point2f> Result;
	vector<Point2f> Temp;
	vector<vector<Point>> Contours;

	findContours(Image, Contours, RETR_CCOMP, CHAIN_APPROX_NONE);
	for (int i = 0, j = static_cast<int>(Contours.size()); i < j; ++i) {
		approxPolyDP(Contours[i], Temp, ApproximationError, true);
		if (Temp.size() != 4) continue;
		Area = contourArea(Temp, false);
		if (Area < AreaMinimum) continue;
		if (Area > AreaMaximum) {
			AreaMaximum = Area;
			Result = Temp;
		}
	}

	return Result;
}

vector<Point2f> SortVertex(vector<Point2f> Data) {
	Point2f Center;
	vector<Point2f> Result(4);

	Center.x = (Data[0].x + Data[1].x + Data[2].x + Data[3].x) / 4;
	Center.y = (Data[0].y + Data[1].y + Data[2].y + Data[3].y) / 4;
	for (int i = 0; i < 4; ++i) {
		if (Data[i].x <= Center.x&&Data[i].y <= Center.y) Result[0] = Data[i];
		else if (Data[i].x >= Center.x&&Data[i].y <= Center.y) Result[1] = Data[i];
		else if (Data[i].x >= Center.x&&Data[i].y >= Center.y) Result[2] = Data[i];
		else if (Data[i].x <= Center.x&&Data[i].y >= Center.y) Result[3] = Data[i];
	}

	return Result;
}