#pragma once
#define _CRT_SECURE_NO_WARNINGS
#define _USE_MATH_DEFINES

#include <cmath>
#include <climits>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <vector>
#include <opencv2/opencv.hpp>
#include <tchar.h>
#include <Windows.h>

#define ERR_CAM_NOAVALIABLE 301
#define ERR_CAM_NOCONNECTION 302
#define ERR_COM_BUFSIZE 303
#define ERR_COM_FLUSH 304
#define ERR_COM_GETDCB 305
#define ERR_COM_OPEN 306
#define ERR_COM_SETDCB 307
#define ERR_COM_SETTOUT 308
#define ERR_COM_WRITE 309

#define NUM_APPROX_EPS 30
#define NUM_CAM_HEIGHT 480
#define NUM_CAM_WIDTH 640
#define NUM_CM2PX (NUM_CAM_HEIGHT/65.0)
#define NUM_BALL_RADIUS (NUM_CM2PX*0.3)
#define NUM_COM_BAUDRATE CBR_115200
#define NUM_COM_DATASIZE 6
#define NUM_COM_INTERVAL 200
#define NUM_DRAWC_RADIUS 4
#define NUM_IMSHOW_DELAY 1
#define NUM_MARGIN_CM 5.0
#define NUM_MARGIN_LR (NUM_CM2PX*NUM_MARGIN_CM)
#define	NUM_MARGIN_UD (NUM_CM2PX*NUM_MARGIN_CM)
#define NUM_TEXT_SCALE 0.8
#define NUM_THICKNESS 2

#define STR_TITLE_BALL "Ball - Binarized Board"
#define STR_TITLE_BOARD "Ball - Original Board"
#define STR_TITLE_FULL "Ball - Camera Real-time"
#define STR_TITLE_SEG "Ball - Color Segmentation"

using namespace cv;
using namespace std;

enum BallPositionValue {
	Up = 0,
	Down = 1,
	Left = 2,
	Right = 3
};
enum RGBValue {
	Blue = 0,
	Green = 1,
	Red = 2
};

typedef struct {
	int Baudrate;
	int COM;
	int Error;
	HANDLE Serial;
	string Content;
}InitSerialData;
typedef struct {
	int Error;
	unsigned int Interval;
	DWORD Size;
	DWORD Transferred;
	HANDLE Serial;
	Point Data;
	string Content;
	SYSTEMTIME Past;
}SendDataConf;

void DrawTetragon(Mat &Image, vector<Point2f> Vertices, Scalar Color, int Thickness);
void GenerateNoSignal(Mat &Image, Size ImageSize, int ColorHex);
void InitializeSerial(InitSerialData &Data);
void PrintErrorExit(int Error, string Content);
void SendData(SendDataConf &Conf);
Point FindBall(Mat Image, double RangeUD, double RangeLR, double RadiusMinimum);
vector<Point2f> FindBoard(Mat Image, int ApproximationError, int AreaMinimum);
vector<Point2f> SortVertex(vector<Point2f> Data);