#include<opencv2/core/core.hpp>
#include<opencv2/highgui/highgui.hpp>
#include<iostream>
using namespace cv;  
using namespace std;
Mat frame;  //定义一个Mat变量，用于存储每一帧的图像
double time0;int exposure =-1;
int main( )  {  	
	//【1】从摄像头读入视频	
	VideoCapture capture(1);	
	if(false == capture.isOpened())	
	{		return -1;	}
	double h = capture.get(CV_CAP_PROP_FRAME_WIDTH);
	double a = capture.get(CV_CAP_PROP_FRAME_HEIGHT);
    double b = capture.get(CV_CAP_PROP_FPS);
    double c = capture.get(CV_CAP_PROP_BRIGHTNESS);
    double d = capture.get(CV_CAP_PROP_CONTRAST);
    double e = capture.get(CV_CAP_PROP_SATURATION);
    double f = capture.get(CV_CAP_PROP_HUE);
    double g = capture.get(CV_CAP_PROP_EXPOSURE); 
	cout << "宽度   " << h << "高度   " << a << endl;
	cout << "帧率   " << b << "亮度   " << c << endl;
	cout << "对比度   " << d << "饱和度   " << e << endl;
	cout << "色调   " << f << "曝光   " << g << endl;
	capture.set(CV_CAP_PROP_FRAME_WIDTH, 800);//宽度
	//capture.set(cv::CAP_PROP_AUTO_EXPOSURE, 0.25)
	capture.set(CV_CAP_PROP_FRAME_HEIGHT,400 );//高度

	capture.set(CV_CAP_PROP_FPS,120 );//帧率 帧/秒

	capture.set(CV_CAP_PROP_BRIGHTNESS,30 );//亮度 

	capture.set(CV_CAP_PROP_CONTRAST,40 );//对比度 

	capture.set(CV_CAP_PROP_SATURATION,50 );//饱和度 

	capture.set(CV_CAP_PROP_HUE, 50);//色调 
	capture.set(CV_CAP_PROP_EXPOSURE,-11 );//曝光 
	//获取摄像头参数
	h = capture.get(CV_CAP_PROP_FRAME_WIDTH);
	a = capture.get(CV_CAP_PROP_FRAME_HEIGHT);
	b = capture.get(CV_CAP_PROP_FPS);
	c = capture.get(CV_CAP_PROP_BRIGHTNESS);
	d = capture.get(CV_CAP_PROP_CONTRAST);
	e = capture.get(CV_CAP_PROP_SATURATION);
	f = capture.get(CV_CAP_PROP_HUE);
	g = capture.get(CV_CAP_PROP_EXPOSURE);
	cout << "宽度   " << h << "高度   " << a << endl;
	cout << "帧率   " << b << "亮度   " << c << endl;
	cout << "对比度   " << d << "饱和度   " << e << endl;
	cout << "色调   " << f << "曝光   " << g << endl;
	while(1)  	{  				
		time0 = static_cast<double>(getTickCount( ));//记录起始时间		
		capture >> frame;  //读取当前帧		//若视频播放完成，退出循环		
		if (frame.empty())		
		{
			break;		
		}		
		imshow("UVC",frame);  //显示当前帧		//显示帧率		//
		cout << ">帧率= " << getTickFrequency() / (getTickCount() - time0) << endl;		
		char c = (char)waitKey(10);		
		if( c == 27 )			
			break;	
	}  	
	return 0;  
}   